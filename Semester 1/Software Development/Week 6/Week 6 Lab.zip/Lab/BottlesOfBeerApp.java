/*
Week 6 Lab - Exercise 1 BottlesOfBeerApp.java
Denis Murray
07/11/22
*/
public class BottlesOfBeerApp {
	public static void main(String args []) {
		BottlesOfBeer game = new BottlesOfBeer();

		game.startSong();
	}
}