public class Initials {
	public static void main(String [] args) {
		System.out.println("JJJJJJJ  PPPPPP");
		System.out.println("   J     P    P");
		System.out.println("   J     PPPPPP");
		System.out.println("   J     P");
		System.out.println(" JJJ     P");
	}
}