/*
*MyFirstProgram.java
*@author S.Cogan
*
*/

//class definition
public class MyFirstProgram{
	//main method header
	public static void main(String [] args){
		System.out.println("I love Maths");
		System.out.println("And I love java too");

	}
}